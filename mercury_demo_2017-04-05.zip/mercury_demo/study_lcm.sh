#/bin/bash

CONTAINERS=(
            i-msb i-esr
            i-catalog i-aria
            i-sdnos-mss i-sdnos-brs
            i-sdnos-lcm
            )

stop=$@

i=0
len=${#CONTAINERS[*]}

while [ $i -lt $len ]; do
    container=${CONTAINERS[$i]}

    if [ "$stop" == "stop" ]
    then
        sudo docker stop $container
    else
        sudo docker start $container
        sleep 10
    fi

    let i++
done


#start a fresh simulator for sdno-lcm sbis
sudo docker rm -f i-sdnos-lcmsbis
sudo docker run -d --name i-sdnos-lcmsbis --network openo-net --ip 172.18.5.2 -v /root/mercury_demo/filebeat/log:/service/log -e MSB_ADDR=172.18.0.2:80 --entrypoint /service/docker-entrypoint-allinone.sh openoint/simulate-sdno-services

#start a fresh filebeat
sudo docker rm -f i-filebeat
sudo docker run -d --name i-filebeat --network openo-net --ip 172.18.5.3 -v /root/mercury_demo/filebeat/log:/var/log:ro -v /root/mercury_demo/filebeat/filebeat-config.yml:/root/config.yml logzio/logzio-filebeat

#/bin/bash

sudo docker rm -f i-sdnos-mss
sudo docker run -d -t --name i-sdnos-mss --network openo-net --ip 172.18.3.2 -e MSB_ADDR=172.18.0.2:80 openoint/sdno-service-mss
sleep 60   #wait for database initialization

sudo docker rm -f i-esr
sudo docker run -d -t --name i-esr --network openo-net --ip 172.18.0.3 -e MSB_ADDR=172.18.0.2:80 openoint/common-services-extsys

sudo docker rm -f i-catalog
sudo docker run -d -t --name i-catalog --network openo-net --ip 172.18.1.2 -e MSB_ADDR=172.18.0.2:80 openoint/common-tosca-catalog

#/bin/bash

source ./openo-docker-functions.sh

CONTAINERS=(i-msb i-esr
            i-catalog i-inventory i-aria
            i-gso-gateway i-gso-manager
            i-sdnos-mss i-sdnos-brs
            i-sdnos-lcm
            )


IMAGES=(common-services-msb common-services-extsys
        common-tosca-catalog common-tosca-inventory common-tosca-aria
        gso-service-gateway gso-service-manager
        sdno-service-mss sdno-service-brs
        sdno-service-lcm
        )



IPS=(172.18.0.2 172.18.0.3
     172.18.1.2 172.18.1.3 172.18.1.4
     172.18.2.2 172.18.2.3
     172.18.3.2 172.18.3.3
     172.18.4.2)

MSB_IPPORT=172.18.0.2:80
NSLCM_MYSQL_ADDR=172.18.1.3:3306

#clean all docker containers, recreate the network for open-o
docker_clean_all

sudo docker network rm openo-net
sudo docker network create --subnet=172.18.0.0/16 openo-net


#get the latest docker images
#docker_sync_all

#start all services one by one
docker_start_all

#stop all docker containers
sudo docker stop $(sudo docker ps -a -q)

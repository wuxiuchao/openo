#/bin/bash

####################### clean containers
function docker_clean_all () {
    echo "-------------------- clean (stop and rm) all related containers. ----------------"

    i=0
    len=${#CONTAINERS[*]}

    while [ $i -lt $len ]; do
        container=${CONTAINERS[$i]}
        echo "Container to clean: $container"
        sudo docker stop $container
        sudo docker rm $container

        let i++
    done
}


####################### sync images with hub
function docker_sync_all () {
    echo "-------------------- synchronize all related images ----------------"

    i=0
    len=${#CONTAINERS[*]}

    while [ $i -lt $len ]; do
        image="openoint/${IMAGES[$i]}"
        echo "Image to sync: $image"
        sudo docker pull $image

        let i++
    done
}


###################### launch all services
function docker_start_all () {
    echo "-------------------- Start all related containers/images ----------------"

    i=0
    len=${#CONTAINERS[*]}

    while [ $i -lt $len ]; do
        container=${CONTAINERS[$i]}
        image="openoint/${IMAGES[$i]}"
        ipaddr=${IPS[$i]}
        echo "container/image to start! Image: $image   Container: $container IP: $ipaddr"

        if [ "$container" == "i-msb" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr $image
            sleep 60
        elif  [ "$container" == "i-sdnos-mss" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT $image
            sleep 60
        elif  [ "$container" == "i-sdnos-nslcm" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT -e MYSQL_ADDR=$NSLCM_MYSQL_ADDR  $image
            sleep 3
        else
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT $image
            sleep 3
        fi
  
        let i++
    done
}


###################### launch all services
function docker_start_once_for_all () {
    echo "-------------------- Start all related containers/images ----------------"

    i=0
    len=${#CONTAINERS[*]}

    while [ $i -lt $len ]; do
        container=${CONTAINERS[$i]}
        image="openoint/${IMAGES[$i]}"
        ipaddr=${IPS[$i]}
        echo "container/image to start! Image: $image   Container: $container IP: $ipaddr"

        if [ "$container" == "i-msb" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr $image
            sleep 60
        elif  [ "$container" == "i-sdnos-mss" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT $image
            sleep 60
        elif  [ "$container" == "i-sdnos-nslcm" ]
        then
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT -e MYSQL_ADDR=$NSLCM_MYSQL_ADDR  $image
            sleep 3
        else
            sudo docker run -d -t --name $container --network openo-net --ip $ipaddr -e MSB_ADDR=$MSB_IPPORT $image
            sleep 3
        fi
  
        if [ $i -gt 8 ] 
        then
            sleep 60 
            sudo docker stop $container
        fi

        let i++
    done
}

